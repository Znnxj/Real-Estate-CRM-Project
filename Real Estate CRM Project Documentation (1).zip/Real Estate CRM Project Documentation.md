**<u>Real Estate CRM Project Documentation</u>** **<u>Project
Overview:</u>**

The Real Estate CRM is designed to streamline property management, lead
tracking, and sales operations for real estate businesses. It helps
agents and managers manage property listings, capture and nurture leads,
schedule property visits, and track deals from start to closure. With
features like customizable reports, dashboards, and dynamic access
controls, the CRM ensures better decision-making and improved
productivity. By addressing key business needs such as organized
property inventory, efficient lead conversion, transparent sales
tracking, and secure data management, this CRM enhances customer
engagement and drives overall business growth.

**<u>Objectives:</u>**

The main goal of building the Real Estate CRM is to centralize and
simplify the management of properties, leads, and client interactions
within a single platform. By streamlining processes such as property
listings, lead nurturing, visit scheduling, and deal tracking, the CRM
reduces manual effort and improves overall efficiency. It enables agents
to focus more on customer engagement while providing managers with
real-time insights through reports and dashboards. From a business
perspective, this leads to faster lead conversions, improved sales
performance, better customer satisfaction, and greater transparency in
operations— ultimately driving higher revenue and growth for the real
estate business.

> **Real** **Estate** **Engagement** **&** **Lead** **Conversion**
> **System**
>
> **Phase** **1:** **Problem** **Understanding** **&** **Industry**
> **Analysis**

**1.** **Introduction**

The real estate industry deals with thousands of property inquiries
every day from websites, social media, and offline events.

Currently, many companies manage these inquiries manually using emails
and Excel sheets. This leads to:

> • Missed follow-ups
>
> • Delayed property visits
>
> • Slow deal closures
>
> • Lack of proper reporting

**Solution** **→** **Salesforce** **CRM**

> • Capture and store all leads in one system
>
> • Assign leads automatically to agents
>
> • Maintain property details in a structured way
>
> • Track customer visits and meetings
>
> • Manage deals from start to closure
>
> • Provide managers with real-time dashboards and reports

**2.** **Requirements**

**Business** **Requirements**

> • Centralized system to capture all property leads
>
> • Automatic lead assignment to sales agents
>
> • Property catalog with location, type, and price
>
> • Track visit schedules and reminders
>
> • Deal pipeline management (Open → Negotiation → Closed)
>
> • Simple dashboards for performance tracking

**Functional** **(Admin** **+** **Developer)**

> • Web-to-Lead setup for capturing leads
>
> • Custom **Property** **Object** with fields (price, type, location,
> status)
>
> • Lead assignment rules or queues
>
> • Opportunities for deal tracking
>
> • Reports and dashboards for agents and managers

**Non-Functional**

> • Easy to use for beginners and non-technical staff
>
> • Secure with profiles, roles, and permissions
>
> • Accessible on Salesforce mobile app

**3.** **Stakeholders**

||
||
||
||

||
||
||
||
||
||
||
||

**4.** **Business** **Process** **Mapping**

||
||
||
||
||
||
||
||
||

**5.** **Industry** **Use** **Cases**

> • **Lead** **Management** → Capture and assign leads automatically
>
> • **Property** **Management** → Store property details in Salesforce
> object
>
> • **Visit** **Scheduling** → Track customer visits through
> Events/Tasks
>
> • **Deal** **Tracking** → Use Opportunities to track deal stages
>
> • **Reports** **&** **Dashboards** → Monitor sales and performance
>
> **Phase** **1** **Deliverables**
>
> • Requirements gathered and documented
>
> • Stakeholders identified with their needs
>
> • Current vs Salesforce process mapped
>
> • Real estate use cases defined
>
> • Optional apps explored
>
> **Phase** **2:** **Org** **Setup** **&** **Configuration**
>
> **1.** **Introduction**
>
> In this phase, we configure the Salesforce Developer Org to prepare
> the environment for building **SmartProperty** **CRM** **–** **Real**
> **Estate** **Engagement** **&** **Lead** **Conversion** **System**.
>
> The setup ensures the org has correct company settings, security, user
> hierarchy, and access policies.
>
> <img src="./2qwecggu.png"
> style="width:6.26805in;height:3.53889in" />By the end of this phase,
> the system will be ready for **Phase** **3:** **Data** **Modeling**
> **&** **Relationships**.

<img src="./bpi3geci.png"
style="width:5.175in;height:1.86528in" /><img src="./jf0ovg4q.png"
style="width:4.69917in;height:2.42083in" />

> **2.** **Salesforce** **Editions**
>
> • Using **Salesforce** **Developer** **Edition** **(Free)**
>
> • Provides:
>
> o Custom Objects & Fields
>
> o App Builder & LightningApps
>
> o Users, Profiles, Roles, Permission Sets
>
> o Reports & Dashboards
>
> **3.** **Company** **Profile** **Setup**
>
> **Navigation:** Setup → Company Settings → Company Information

<img src="./bi50nifl.png"
style="width:6.26805in;height:3.57361in" />

> • Company Name → SmartProperty CRM
>
> • Default Currency → INR (₹)
>
> • Locale → English (India)
>
> • Time Zone → (GMT +5:30) India Standard Time
>
> **4.** **Business** **Hours** **&** **Holidays**
>
> **Navigation:** Setup → Company Settings → Business Hours
>
> • Business Hours → 9:00 AM – 6:00 PM, Monday to Saturday
>
> • Holidays (Examples):
>
> o Republic Day (26th Jan)
>
> o Diwali
>
> o New Year (1st Jan)
>
> **5.** **Fiscal** **Year** **Settings**
>
> **Navigation:** Setup → Company Settings → Fiscal Year
>
> • Standard Fiscal Year → April 1 to March 31

<img src="./bizj1u5o.png"
style="width:5.50389in;height:3.35694in" />

> **6.** **User** **Setup** **&** **Licenses**
>
> **Navigation:** Setup → Users → New User
>
> • Created sample users:
>
> o Sales Agent → Standard Salesforce License
>
> o Property Manager → Salesforce Platform License
>
> o Sales Manager → Standard Salesforce License
>
> **7.** **Profiles**
>
> **Navigation:** Setup → Profiles
>
> • Cloned **Standard** **User** **Profile** **→** **Sales** **Agent**
> **Profile**
>
> • Gave CRUD access to: Leads, Opportunities, and (later) Property
> Object

<img src="./5kwzjpdz.png"
style="width:6.26805in;height:1.76111in" /><img src="./exvo3qta.png"
style="width:6.26805in;height:3.16389in" />

> **8.** **Roles** **(Hierarchy)**
>
> **Navigation:** Setup → Roles → Set Up Roles Hierarchy Defined:
>
> • Executive (Top level)
>
> • Sales Manager
>
> • Sales Agent
>
> (Ensures managers can view their team’s records.)
>
> **9.** **Permission** **Sets**
>
> **Navigation:** Setup → Permission Sets → New
>
> • Created: **Property** **Management** **Access**
>
> • CRUD access for Property Object (to be created in Phase 3)
>
> • Assigned to Property Manager user
>
> <img src="./pgoopj2x.png"
> style="width:6.26805in;height:3.52431in" />•
>
> **10.** **Organization-Wide** **Defaults** **(OWD)**
>
> **Navigation:** Setup → Sharing Settings
>
> • Leads → Private
>
> • Opportunities → Private
>
> • Property (custom object – Phase 3) → Public Read/Write
>
> **11.** **Sharing** **Rules**
>
> **Navigation:** Setup → Sharing Settings → New Sharing Rule
>
> • Example: **Share** **Leads** **owned** **by** **“East** **Team”**
> **with** **West** **Team**
>
> <img src="./bq1tzrr4.png"
> style="width:6.26805in;height:3.52431in" />•
>
> **12.** **LoginAccess** **Policies**
>
> **Navigation:** Setup → Login Access Policies
>
> • Enabled: **Administrators** **Can** **Log** **In** **as** **Any**
> **User**
>
> • (Optional) Restricted logins by IP range for security
>
> <img src="./zf4jsnda.png"
> style="width:6.26805in;height:3.52431in" />•
>
> **13.** **Dev** **Org** **Setup** **&** **Sandbox** **Usage**
>
> • Working in **Developer** **Edition** **Org** **(free)**
>
> • Sandboxes are **not** **available** in Developer Edition
>
> • Practice done directly in Dev Org
>
> **14.** **Deployment** **Basics**
>
> • Initial setup done directly in Dev Org
>
> • Future deployment methods:
>
> o Change Sets (click-based)
>
> o SFDX CLI + GitHub (for advanced version control)
>
> **Phase** **2** **Deliverables**
>
> • Salesforce Developer Org created and verified
>
> • Company profile updated (currency, locale, timezone)
>
> • Business hours and holidays defined
>
> • Fiscal year configured
>
> • Users created (Agent, Manager, Property Manager)
>
> • Profiles cloned and updated
>
> • Roles defined in hierarchy
>
> • Permission sets created
>
> • OWD and Sharing Rules implemented
>
> • Login access policies updated

**<u>Phase3-Data Modeling and Relationships phase:</u>** 1. Standard &
Custom Objects

> o Standard: Contact (buyers, sellers, agents).
>
> o Custom: Property, Visit/Appointment, Deal.

<img src="./csl3ve4b.png"
style="width:6.26805in;height:3.52569in" /><img src="./hv15z1wt.png"
style="width:6.26805in;height:3.52569in" /><img src="./5aug3p4h.png"
style="width:6.26805in;height:2.14167in" />

<img src="./owavop34.png"
style="width:6.26805in;height:3.52569in" />

> 2\. Fields
>
> o Property: Location, Price, Size (sq ft), Status (Available, Sold,
> Under Negotiation).
>
> o Visit/Appointment: Date, Time, Notes.
>
> o Deal: Deal Value, Closing Date, Deal Status.
>
> 3\. Record Types
>
> o Property: “Residential” vs “Commercial.”
>
> o Deal: “Rent” vs “Sale.”
>
> 4\. Page Layouts
>
> o Property page: Shows related visits and deals.
>
> o Deal page: Shows related property and customer details.
>
> o Contact page: Shows properties visited, deals closed.
>
> 5\. Compact Layouts
>
> o Mobile (Property): Location, Price, Status.
>
> o Mobile (Deal): Deal Value, Closing Date, Status.

<img src="./ciemjexc.png"
style="width:5.32569in;height:3.52569in" />

> 6\. Schema Builder
>
> o Used to visualize relationships among Property, Deal, Contact,
> Visit.
>
> 7\. Lookup vs Master-Detail
>
> o Property ↔ Deal → Lookup (a deal is associated with a property, but
> property can exist without a deal).
>
> o Deal ↔ Contact → Lookup (a deal links to a buyer/seller).
>
> o Visit ↔ Property → Lookup (a visit relates to a property, but
> property exists independently).

<img src="./krv1cxx0.png"
style="width:6.26805in;height:3.52569in" /><img src="./skfoop0o.png"
style="width:6.26805in;height:3.52569in" />

**<u>Phase 4- Implementation – Real Estate CRM Project</u>** 1.
Validation Rules

> o Example: Property Price must be greater than 0.
>
> o Example: Deal Closing Date must be after Visit Date.

<img src="./nyk0wa2n.png"
style="width:4.49153in;height:2.52639in" /><img src="./rskqdpz4.png"
style="width:4.78653in;height:2.69236in" /><img src="./fs43rw2s.png"
style="width:3.83097in;height:2.15486in" />

> 2\. Approval Process
>
> o Deal Value \> ₹50,00,000 → Send for Manager approval.
>
> 3\. Flow Builder

<img src="./41lqbajm.png"
style="width:3.74819in;height:2.10833in" /><img src="./iphiaewk.png"
style="width:3.85069in;height:2.16597in" />

> o Record-triggered Flow: Auto-calculate commission percentage when a
> deal is created/closed.
>
> o Screen Flow: Guided property booking/visit form for agents.
>
> 4\. EmailAlerts
>
> o Send confirmation email to customer after deal approval.
>
> 5\. Field Updates
>
> o After approval, Deal Status = “Closed Won.”
>
> 6\. Tasks
>
> o

Create a task for the agent to schedule a property visit or follow-up
with the buyer.

> 7\. Custom Notifications
>
> o Send in-app notification to the agent when a high-value deal is
> approved.

**<u>Phase 6: User Interface Development – Real Estate CRM</u>**
1.Lightning App Builder

> <img src="./12gbvw3a.png"
> style="width:5.22236in;height:2.9375in" /><img src="./cold5ug3.png"
> style="width:5.25319in;height:2.95486in" /><img src="./nxmgkcje.png"
> style="width:5.2675in;height:1.9743in" />• Create a “Real Estate CRM”
> app to manage properties, clients, deals, and site visits.

<img src="./n3wsfjfs.png"
style="width:4.0368in;height:2.27069in" /><img src="./0xvf5oha.png"
style="width:3.93472in;height:2.21319in" />

2\. Record Pages

> • Property Page → Display key details (location, price, availability,
> property type).
>
> • Show related lists: Enquiries and Site Visits linked to the
> property.
>
> • Client Page → List of enquiries, visits, and deals related to the
> client.

3\. Tabs

> <img src="./tup5yb4z.png"
> style="width:2.81236in;height:1.58194in" />• Add Properties, Clients,
> Enquiries, Site Visits, and Deals tabs for easy navigation.

<img src="./pqsn4prd.png"
style="width:3.83819in;height:2.15889in" /><img src="./fiofkc2k.png"
style="width:3.71611in;height:2.09028in" />

4\. Home Page Layouts

> • Dashboard with:
>
> o Total Active Properties
>
> o Upcoming Site Visits
>
> o Conversion Funnel (Enquiries → Visits → Deals)
>
> o Top Performing Agents

5\. Utility Bar

> • Quick actions:
>
> o “New Enquiry” (fast client entry form).
>
> o “Schedule Site Visit” shortcut.

6\. Lightning Web Component (LWC)

> • Component: Search Properties by filters (location, budget, property
> type, availability).
>
> • Display search results in a datatable with actions like *View*
> *Details*, *Book* *Visit*.

<img src="./ffx1gyw5.png"
style="width:2.60875in;height:1.46736in" />

7\. Apex with LWC

> • ImperativeApex call → create new Enquiry or Site Visit record when a
> client shows interest in a property.

8\. Events in LWC

> • Child component (Search Form) → passes search criteria (budget,
> location) to parent.
>
> • Parent component (Results) → displays matching properties
> dynamically.

9\. WireAdapters

> • Wire available Property records from Salesforce to display real-time
> listings in the UI.

10\. ImperativeApex Calls

> • On “Book Site Visit” → callApex method to create a Site Visit record
> linked to property & client.

11\. Navigation Service

> • After booking a visit or finalizing a deal → navigate directly to
> the related Enquiry / Deal record page for seamless workflow.

**<u>Phase 7: Integration & External Access – Real Estate CRM</u>**

1\. Named Credentials

> • Store Property Listing API or Government Land Registry API
> credentials securely for safe integrations.

2\. External Services

> • Connect with Mortgage/Loan Verification Services or Property
> Valuation APIs.

<img src="./qb0vlop0.png"
style="width:3.6643in;height:2.06111in" /><img src="./f2ybikbi.png"
style="width:3.59389in;height:2.02153in" />

3\. Web Services (REST/SOAP)

> • REST callout: Fetch latest property valuation or ownership details
> from an external registry.
>
> • SOAP callout: Verify legal documents of a property.

4\. Callouts

> • Triggered when:
>
> o A new Property is added → call external API to verify property
> details.
>
> o A Deal is created → trigger loan/mortgage eligibility check.

5\. Platform Events

> • Publish event if:
>
> o A Property Status changes (e.g., Available → Booked → Sold).
>
> o A Site Visit is canceled and notify external calendar/integration
> system.

<img src="./w0vbxi3y.png"
style="width:3.24819in;height:1.82708in" /><img src="./5mp00yss.png"
style="width:3.70972in;height:2.08667in" /><img src="./2bhfzmbu.png"
style="width:3.79444in;height:1.43736in" />

6\. Change Data Capture (CDC)

> • If Property details (price, availability) or Deal status (Pending →
> Closed) is updated → notify connected portals or partner systems.

7\. Salesforce Connect

> • Connect to external Property Management Databases if real estate
> listings are maintained outside Salesforce.

8\. API Limits

> • Monitor API calls/day especially when syncing with:
>
> o Multiple Property Portals
>
> o Bank Loan/Mortgage services

<img src="./vt4jli0p.png"
style="width:3.86306in;height:2.17292in" /><img src="./kbjz5pyf.png"
style="width:4.30625in;height:2.42222in" />

> o Government verification systems

9\. OAuth &Authentication

> • If clients log in via a Real Estate Customer Portal, use OAuth for
> secure authentication.
>
> • Enable partner brokers to securely access shared property data.

10\. Remote Site Settings

> • Allow callouts to:
>
> o External listing portals
>
> o Government property verification domains
>
> o Bank/MortgageAPIs

**<u>Phase 8: Data Management & Deployment – Real Estate CRM</u>** 1.
Data Import Wizard

<img src="./zfacd1bw.png"
style="width:3.65764in;height:2.05736in" /><img src="./c3l4jy03.png"
style="width:2.81236in;height:1.58194in" />

> • Import 50 demo Property records (location, price, type, status).

2\. Data Loader

> • Import bulk Enquiries, Site Visits, and Deals for testing large
> datasets.

3\. Duplicate Rules

> • Prevent duplicate Property or Client entries (e.g., same property
> listed twice, or same client registered with multiple emails).

<img src="./lv32nbqo.png"
style="width:6.26805in;height:3.52569in" /><img src="./wcfznm4s.png"
style="width:6.26805in;height:3.52569in" />

4\. Data Export & Backup

> • Weekly backup of all Properties, Clients, Enquiries, Site Visits,
> and Deals to ensure recovery in case of data loss.

5\. Change Sets

> • Move custom objects, fields, record pages, and automation from
> Sandbox → Production.

<img src="./qnjyyovc.png"
style="width:3.67167in;height:2.06528in" /><img src="./cblxlkvp.png"
style="width:6.26805in;height:3.52569in" />

6\. Unmanaged vs Managed Packages

> • Unmanaged: Internal deployment for customization.
>
> • Managed: If the Real Estate CRM needs to be published on AppExchange
> for other realtors/agencies.

7\. ANT Migration Tool

> <img src="./mgfynoyn.png"
> style="width:2.26181in;height:1.27222in" />• Use command-line
> deployment for moving metadata in bulk between orgs.

<img src="./dbnokpi3.png"
style="width:5.42222in;height:3.04986in" />

8\. VS Code & SFDX

> • Enable developer-friendly deployments with version control (Git) and
> automated scripts for continuous integration & delivery (CI/CD).

**<u>Phase 9: Reporting, Dashboards & Security Review</u>**

1\. Reports

○ Property Listings by Status (Available, Sold, Rented). ○ Revenue by
Property Type (Residential, Commercial). ○ Lead Conversion Report (Leads
→ Deals).

○Agent Performance (Deals Closed, Visits Completed).

<img src="./qpslogl4.png"
style="width:6.26805in;height:3.52569in" />

> 2\. Report Types
>
> <img src="./gbruqmyy.png"
> style="width:6.26805in;height:3.52569in" />○ Custom report: Property +
> Visit Scheduling + Deals.

<img src="./xrhe1has.png"
style="width:4.60139in;height:2.58819in" />

> 3\. Dashboards
>
> <img src="./jepvxnhi.png"
> style="width:6.26805in;height:3.52569in" />○ Property Portfolio
> Dashboard. ○ Sales & Revenue Dashboard. ○Agent Performance Dashboard.

4.Dynamic Dashboards

○ EachAgent sees only their leads, visits, and deals.

> 4\. Sharing Settings
>
> ○ Leads & Deals private, Properties public.

<img src="./a0aggic3.png"
style="width:6.26805in;height:3.52569in" /><img src="./tobxjmpf.png"
style="width:6.26805in;height:3.52569in" />

> 5\. Field Level Security
>
> ○ Hide “Customer Financial Details” from Agents.
>
> 6\. Session Settings
>
> ○ Timeout after 30 mins of inactivity.

<img src="./230ch0kg.png"
style="width:6.26805in;height:3.52569in" /><img src="./ybfjzbax.png"
style="width:6.26805in;height:3.52569in" />

> 7\. Login IP Ranges
>
> ○ Restrict agents to office or authorized IP ranges.

9.Audit Trail

○ Track who made changes to Leads, Properties, and Deals.

<img src="./m3rdwapa.png"
style="width:6.26805in;height:3.52569in" />

**<u>Phase 10: Final Presentation & Demo Day</u>**

> 1\. Pitch Presentation
>
> ○ Problem → Lack of organized property & lead management.
>
> ○ Solution → Real Estate CRM with lead tracking, property management,
> visit scheduling, and deal closure.
>
> ○ Benefits → Improved sales efficiency, better customer engagement,
> transparent reporting.
>
> 2\. Demo Walkthrough
>
> ○ Show creating a new lead and assigning to an agent. ○ Schedule a
> property visit and track status.
>
> ○ Convert lead → deal and update property status (Sold/Rented). ○
> Generate revenue & agent performance report.
>
> 3\. Handoff Documentation
>
> ○ Share system design document.
>
> ○ Provide user guide for agents and managers.
>
> 4\. LinkedIn/Portfolio Project Showcase
>
> ○ Publish project summary with screenshots/demos.
>
> ○ Highlight features like dashboards, dynamic reports, and security
> controls.
